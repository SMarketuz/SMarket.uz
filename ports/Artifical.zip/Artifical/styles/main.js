'use struct'


// ()

let left = document.querySelector('.leftNav')
let bntclose = document.querySelector('#close')
let barsBtn = document.getElementById('bars')
let hed = document.querySelector('#hed')
let content = document.querySelector('.container')
let tot = document.getElementById('tot')
let miya = document.querySelector('.h1set')
let bot = document.getElementById('bot')
let lang = document.getElementById('lang')



bot.addEventListener('click', (e)=> {
    lang.style.display = 'block'
})



barsBtn.addEventListener('click',(e)=> {
    left.style.display = 'block'
    hed.style.display = 'none'
})
bntclose.addEventListener('click',(e)=> {
    left.style.display = 'none'
    hed.style.display = 'block'
})
setInterval(() => {
    tot.textContent ='Good morning'
    tot.style.color ='pink'
},2000);
setInterval(() => {
    tot.textContent ='Good afternoon'
    tot.style.color ='aqua'
    lang.style.display = 'none'
    
},4000);
setInterval(() => {
    tot.textContent ='Good evening'
    tot.style.color ='yellow'
},6000);
setInterval(() => {
    tot.textContent ='Good night'
    tot.style.color ='purple'
},8000);
setInterval(() => {
    tot.textContent ='Artificial Intelligence'
},10000);

setInterval(() => {
    miya.textContent ='Naxly as the Winners in Global Agency Award'
    miya.style.color = 'blue'
},2000);
setInterval(() => {
    miya.textContent ="What our clients say about our awesome solutions"
    miya.style.color = 'aqua'
},4000);
setInterval(() => {
    miya.textContent ='Artificial intelligence  & Syber securit'
    miya.style.color = 'yellow'
},6000);
setInterval(() => {
    miya.textContent ='Apply AI, Deep Learning  and Data Sciece to solve'
    miya.style.color = 'purple'
},8000);


