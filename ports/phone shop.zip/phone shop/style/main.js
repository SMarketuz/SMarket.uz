'use stiruct'

// ()

let clos = document.getElementById('close')
let leftNav = document.querySelector('.leftNav')
let bars = document.getElementById('burger')
let header = document.getElementById('header')

clos.addEventListener('click',(e)=> {
    leftNav.style.display = 'none'
    header.style.display = 'block'
})

bars.addEventListener('click',(e)=> {
    leftNav.style.display = 'block'
    header.style.display = 'none'
})