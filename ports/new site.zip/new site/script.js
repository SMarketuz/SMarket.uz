window.addEventListener("load",() => {
    let loader = document.querySelector(".loader")
    setTimeout(() => {
        loader.style.opacity = 0;
        setTimeout(() => {
            loader.style.display = 'none'
        }, 300)
    })
})


let bars = document.querySelector(".fa-bars")
let right = document.querySelector(".right")
let xmark = document.querySelector(".fa-xmark")

bars.addEventListener("click",()=> {
    right.style.display = "flex"
    right.style.animationName = "animateMenu"
})

xmark.addEventListener("click",()=> {
    right.style.display = "none"
    right.style.animationName = "animationBarTwo"
})
