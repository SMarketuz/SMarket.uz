'use strict'
// // // ()
let bars = document.querySelector('#bars')
let navbar = document.querySelector('.left-content')
let nav = document.querySelector('.nav')
let key = document.querySelector('#key')

bars.addEventListener('click',(e)=> {
    navbar.style.display = 'block'
    nav.style.display = 'none'
    nav.style.height = '100%'
})
key.addEventListener('click',(e)=> {
    navbar.style.display = 'none'
    nav.style.display = 'block'
    nav.style.display = 'flex'

})